//
//  SCPCharge.h
//  StripeTerminal
//
//  Created by Ben Guo on 7/27/17.
//  Copyright © 2017 Stripe. All rights reserved.
//

#import "SCPJSONDecodable.h"

NS_ASSUME_NONNULL_BEGIN

/**
 The possible statuses for a charge
 */
typedef NS_ENUM(NSUInteger, SCPChargeStatus) {
    /**
     The charge succeeded.
     */
    SCPChargeStatusSucceeded,
    /**
     The charge succeeded.
     */
    SCPChargeStatusPending,
    /**
     The charge failed.
     */
    SCPChargeStatusFailed,
} NS_SWIFT_NAME(ChargeStatus);

@class SCPCardPresentSource;

/**
 An object representing a Stripe charge.

 @see https://stripe.com/docs/api#charges
 */
@interface SCPCharge : NSObject <SCPJSONDecodable>

/**
 The amount of the charge.
 */
@property (nonatomic, readonly) NSUInteger amount;

/**
 The currency of the charge.
 */
@property (nonatomic, readonly) NSString *currency;

/**
 The status of the charge.
 */
@property (nonatomic, readonly) SCPChargeStatus status;

/**
 The card present source associated with the charge.
 */
@property (nonatomic, nullable, readonly) SCPCardPresentSource *cardPresentSource;

/**
 A string describing the charge, displayed in the Stripe dashboard and in
 email receipts.
 */
@property (nonatomic, nullable, readonly) NSString *stripeDescription;

/**
 Metadata associated with the charge.
 */
@property (nonatomic, readonly) NSDictionary *metadata;

/**
 The unique identifier for the charge.
 */
@property (nonatomic, readonly) NSString *stripeId;

/**
 You cannot directly instantiate this class.
 */
- (instancetype)init NS_UNAVAILABLE;

/**
 You cannot directly instantiate this class.
 */
- (instancetype)new NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
